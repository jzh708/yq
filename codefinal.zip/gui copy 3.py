import tkinter as tk
from cloud import generate_wordcloud_from_file  # 导入 cloud.py 中的函数
from test import *
def do_submit():
    output_text.delete('0.0', 'end')
    output = switcher.get(v.get(), prCNN)(input_text.get('0.0', 'end'))
    output_text.insert(tk.END, output)

def generate_wordcloud():
    # 调用 cloud.py 中的 generate_wordcloud_from_file 函数，传入文件路径
    generate_wordcloud_from_file('TVB_news.csv')  # 这里指定了 TVB_news.csv 文件路径

# 主窗口设置
root_window = tk.Tk()
root_window.title("实体信息抽取-情感分析-数据统计")
root_window.geometry("1280x800")
root_window['background'] = '#7FFFD4'

# 算法选择框设置
model = [('CNN', 1), ('LSTM', 2)]
switcher = {1: prCNN, 2: prLSTM}
v = tk.IntVar()

# 按钮水平排列
for i, (name, num) in enumerate(model):
    btn = tk.Radiobutton(root_window, text=name, variable=v, value=num, indicatoron=False)
    btn.place(relx=0.05 + 0.3 * i, rely=0.1, relwidth=0.25, relheight=0.1)

# 识别按钮
submit = tk.Button(root_window, text='识别', command=do_submit)
submit.place(relx=0.7, rely=0.1, relwidth=0.2, relheight=0.1)

# 生成词云按钮
wordcloud_button = tk.Button(root_window, text='生成词云', command=generate_wordcloud)
wordcloud_button.place(relx=0.7, rely=0.2, relwidth=0.2, relheight=0.1)

# 输入文本框和输出文本框
input_title = tk.Label(root_window, text="输入文本", fg="#000000")
input_title.place(relx=0.1, rely=0.3)
input_text = tk.Text(root_window, autoseparators=True)
input_text.place(relx=0.1, rely=0.35, relwidth=0.38, relheight=0.3)

# 输出文本框
output_title = tk.Label(root_window, text="输出结果", fg="#000000")
output_title.place(relx=0.5, rely=0.3)
output_text = tk.Text(root_window, autoseparators=True)
output_text.place(relx=0.5, rely=0.35, relwidth=0.38, relheight=0.3)

root_window.mainloop()
