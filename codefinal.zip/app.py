import tkinter as tk
from tkinter import filedialog
from cloud import stopwordslist, get_plt, _wordcloud
import re
import jieba
from collections import Counter
from aip import AipNlp  # 导入百度AI SDK

#from test import *

# 百度AI API凭证
APP_ID = '6175065'
API_KEY = 'mezDwLCxasP0oDm7UJI9PbC1'
SECRET_KEY = 'FO4MTnjOq0O7m2rgxQYsJBfKo0XFOuor'

client = AipNlp(APP_ID, API_KEY, SECRET_KEY)

def do_submit():
    output_text.delete('0.0', 'end')
    text = input_text.get('0.0', 'end')
    
    try:
        # 调用百度API进行情感分析
        sentiment_result = client.sentimentClassify(text)
        if 'items' in sentiment_result:
            sentiment = sentiment_result['items'][0]['sentiment']
            if sentiment == 2:
                sentiment = "积极"
            elif sentiment == 0:
                sentiment = "消极"
            elif sentiment == 1:
                sentiment = "中性"
            else:
                sentiment = "未知"
            sentiment_confidence = sentiment_result['items'][0]['confidence']
        else:
            sentiment = "未知"
            sentiment_confidence = 0.0

        # 调用百度API进行实体识别
        entity_result = client.lexer(text)
        if 'items' in entity_result:
            entities = [item['item'] for item in entity_result['items'] if item['ne']]
        else:
            entities = []
        title = ""
        for i in entities:
            title = title + i 
        #print(title)
        topic_result = client.topic(title,text)
        if 'item' in topic_result:
            topics = topic_result['item'][ "lv1_tag_list"][0]["tag"]
            topics = topics + f"\t置信度:{topic_result['item'][ 'lv1_tag_list'][0]['score']}"
        else:
            topics = "未识别到话题"
    
        output = f"情感分析结果: {sentiment} (置信度: {sentiment_confidence})\n实体识别结果: {', '.join(entities)}\n话题识别结果: {topics}"
    except Exception as e:
        output = f"API调用失败: {str(e)}"
    #output = sentiment_result
    output_text.insert(tk.END, output)


def show_wordcloud():
    filepath = filedialog.askopenfilename(title="选择CSV文件", filetypes=[("CSV Files", "*.csv")])
    if filepath:
        words_str = ""
        with open(filepath, encoding='utf-8') as f:
            for line in f:
                line = re.sub(u"[0-9\s+.!/,$%^*()?;；:-【】+\"\']+|[+——！，;:。？、~@#￥%……&*（）＞＜-]+", "", line)
                if line == "": continue
                line = line.replace("\n", "")
                seg_list = jieba.cut(line, cut_all=False)
                words_str += (" ".join(seg_list))

        stopwords = stopwordslist()
        words = [word for word in words_str.split(" ") if word not in stopwords and len(word) > 1]

        word_counts = Counter()
        for x in words:
            word_counts[x] += 1

        get_plt(word_counts.most_common(30), "词频统计图top30")
        _wordcloud(word_counts)

root_window = tk.Tk()
root_window.title("实体信息抽取-情感分析-数据统计")
root_window.geometry("1280x800")
root_window['background'] = '#7FFFD4'

model = [('实体分析', 1), ('立场分析', 2)]
#switcher = {1: prCNN, 2: prLSTM}
v = tk.IntVar()
for i, (name, num) in enumerate(model):
    btn = tk.Radiobutton(root_window, text=name, variable=v, value=num, indicatoron=False)
    btn.place(relx=0.05 + 0.3 * i, rely=0.1, relwidth=0.25, relheight=0.1)



wordcloud_btn = tk.Button(root_window, text="生成词云和词频统计图", command=show_wordcloud)
wordcloud_btn.place(relx=0.35, rely=0.7, relwidth=0.3, relheight=0.1)

input_title = tk.Label(root_window, text="输入文本", fg="#000000")
input_title.place(relx=0.1, rely=0.3)
input_text = tk.Text(root_window, autoseparators=True)
input_text.place(relx=0.1, rely=0.35, relwidth=0.38, relheight=0.3)

submit = tk.Button(root_window, text='识别', command=do_submit)
submit.place(relx=0.7, rely=0.1, relwidth=0.2, relheight=0.1)

output_title = tk.Label(root_window, text="输出结果", fg="#000000")
output_title.place(relx=0.5, rely=0.3)
output_text = tk.Text(root_window, autoseparators=True)
output_text.place(relx=0.5, rely=0.35, relwidth=0.38, relheight=0.3)

root_window.mainloop()